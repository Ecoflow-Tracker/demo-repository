// GEE_MorskieOko.js
// Reproducible exports for Morskie Oko using JRC Global Surface Water v1.4
// Exports: Occurrence.tif, ChangeAbs.tif, a sample Year (waterClass) raster, and
// a CSV time series of annual water area (km²). Also includes ROI export tasks.
//
// --- HOW TO USE ---
// 1) Set ROI:
//    (a) If you drew a polygon in the editor, rename it to ROI in 'Geometry Imports', OR
//    (b) Import your asset geometry and set the variable below.
//       Example: var ROI = ee.FeatureCollection('users/your_username/ROI_MorskieOko').geometry();
//
// 2) Click 'Run' to create Tasks, then start them from the 'Tasks' panel.
//
// --------------------------------------------------------------

// ====== USER SETTINGS ======
var SCALE = 30;                 // meters (GSW is 30 m)
var MAXPIXELS = 1e13;
var DRIVE_FOLDER = 'GEE_MorskieOko';
var FILE_PREFIX = 'MorskieOko';

// ====== ROI ======
// Option A: Use the drawn geometry (rename it to ROI in the editor).
var ROI = (typeof ROI !== 'undefined') ? ROI : geometry; // fallback to 'geometry' if present
// Option B: Use an asset (uncomment and edit):
// var ROI = ee.FeatureCollection('users/your_username/ROI_MorskieOko').geometry();

// ====== DATASETS ======
var gsw = ee.Image('JRC/GSW1_4/GlobalSurfaceWater');              // occurrence, change_abs, etc.
var yearly = ee.ImageCollection('JRC/GSW1_4/YearlyHistory');       // per-year waterClass w/ 'year' property

// ----- OCCURRENCE -----
var occurrence = gsw.select('occurrence').clip(ROI);
Map.addLayer(occurrence, {min:0, max:100, palette:['ffffff','00aaff']}, 'Occurrence (%)', false);

// Export occurrence GeoTIFF
Export.image.toDrive({
  image: occurrence,
  description: FILE_PREFIX + '_Occurrence_30m',
  folder: DRIVE_FOLDER,
  fileNamePrefix: FILE_PREFIX + '_Occurrence_30m',
  fileFormat: 'GeoTIFF',
  region: ROI,
  scale: SCALE,
  maxPixels: MAXPIXELS
});

// ----- CHANGE_ABS -----
var changeAbs = gsw.select('change_abs').clip(ROI);
Map.addLayer(changeAbs, {min:-100, max:100, palette:['8e0152','de77ae','f7f7f7','7fbc41','276419']}, 'Change Abs', false);

// Export change_abs GeoTIFF
Export.image.toDrive({
  image: changeAbs,
  description: FILE_PREFIX + '_ChangeAbs_30m',
  folder: DRIVE_FOLDER,
  fileNamePrefix: FILE_PREFIX + '_ChangeAbs_30m',
  fileFormat: 'GeoTIFF',
  region: ROI,
  scale: SCALE,
  maxPixels: MAXPIXELS
});

// ----- SAMPLE YEAR (waterClass) e.g., 2020 -----
var img2020 = yearly.filter(ee.Filter.eq('year', 2020)).first().clip(ROI);
// waterClass legend (YearlyHistory): 0=no observation, 1=not water, 2=seasonal water, 3=permanent water
Map.addLayer(img2020.select('waterClass'),
  {min:0, max:3, palette:['cccccc','f0f0f0','fee08b','0571b0']},
  'Year 2020 waterClass', false);

Export.image.toDrive({
  image: img2020.select('waterClass'),
  description: FILE_PREFIX + '_waterClass_2020',
  folder: DRIVE_FOLDER,
  fileNamePrefix: FILE_PREFIX + '_waterClass_2020',
  fileFormat: 'GeoTIFF',
  region: ROI,
  scale: SCALE,
  maxPixels: MAXPIXELS
});

// ----- ANNUAL WATER AREA TIME SERIES (km²) -----
// Consider classes 2 (seasonal) and 3 (permanent) as water
var years = ee.List.sequence(1984, 2023);
var tsFC = ee.FeatureCollection(years.map(function(y){
  y = ee.Number(y);
  var img = yearly.filter(ee.Filter.eq('year', y)).first().select('waterClass');
  var water = img.updateMask(img.eq(2).or(img.eq(3)));
  var area_m2 = water.multiply(ee.Image.pixelArea()).reduceRegion({
    reducer: ee.Reducer.sum(),
    geometry: ROI,
    scale: SCALE,
    maxPixels: MAXPIXELS,
    tileScale: 2
  }).get('waterClass');
  var area_km2 = ee.Number(area_m2).divide(1e6);
  return ee.Feature(null, {'year': y, 'water_km2': area_km2});
}));

// Chart (optional in Code Editor UI)
print(ui.Chart.feature.byFeature(tsFC, 'year', 'water_km2')
  .setOptions({
    title: 'Morskie Oko — Annual Water Area (km²)',
    hAxis: {title: 'Year'}, vAxis: {title: 'Water Area (km²)'},
    lineWidth: 1, pointSize: 3
  })
);

// Export CSV of the time series
Export.table.toDrive({
  collection: tsFC.sort('year'),
  description: FILE_PREFIX + '_Yearly_Water_Area_timeseries',
  folder: DRIVE_FOLDER,
  fileNamePrefix: FILE_PREFIX + '_Yearly_Water_Area',
  fileFormat: 'CSV'
});

// ----- OPTIONAL: Export ROI as GeoJSON to Drive -----
var roiFC = ee.FeatureCollection([ee.Feature(ROI)]);
Export.table.toDrive({
  collection: roiFC,
  description: 'ROI_MorskieOko_GeoJSON',
  folder: DRIVE_FOLDER,
  fileNamePrefix: 'ROI_MorskieOko',
  fileFormat: 'GeoJSON'
});

// ----- OPTIONAL: Save ROI as an Asset -----
// (Edit your username and desired asset path)
// Export.table.toAsset({
//   collection: roiFC,
//   description: 'ROI_MorskieOko_asset',
//   assetId: 'users/your_username/ROI_MorskieOko'
// });

// Center map
Map.centerObject(ROI, 13);
