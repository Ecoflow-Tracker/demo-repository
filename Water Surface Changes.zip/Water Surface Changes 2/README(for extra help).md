# Water Surface Changes — Morskie Oko (Poland)

This repository contains a small, reproducible workflow to **detect and visualize surface‑water changes** at the _Morskie Oko_ lake using **Google Earth Engine (GEE)** and local tools (Python / QGIS).  
It includes the Earth Engine script, exported rasters/tables, quick‑look figures, and a ready‑to‑open QGIS project.

---

## 📦 What’s in the project

**Core code & notebooks**
  - GEE_MorskieOko.js

**Data tables (CSV)**
  - MorskieOko_MappingLayers_Stats.csv
  - MorskieOko_Summary_Stats__from_GeoTIFFs_.csv
  - MorskieOko_Yearly_Water_Area.csv
  - MorskieOko_summary_stats.csv
  - Yearly_Water_Area_clean.csv

**Rasters (GeoTIFF)**
  - MorskieOko_ChangeAbs.tif
  - MorskieOko_Occurrence.tif
  - MorskieOko_waterClass_2020.tif

**Figures (PNG)**
  - 1.png
  - 10.png
  - 4.png
  - 5.png
  - 6 OccurrenceHistogram-chart.png
  - 7.png
  - 8.png
  - 9.png
  - Boxplots.png
  - ChangeAbs_histogram.png
  - Occurrence_histogram.png
  - Occurrence_stats_bar (1).png
  - Yearly_Water_Area.png

**GIS project**
  - changeabstif.qgz
  - morskieOko_Occurence.qgz

**Docs & slides**
  - Codes for the Data.docx
  - Water Surface Changes .pptx

> Note: Files are stored under the root of this project (we cleaned out `__MACOSX` entries).
> If you extracted from a zip, keep this relative layout so paths in the QGIS project resolve.

---

## 🚀 Quick start

### 1) Re‑run the analysis in Google Earth Engine
1. Open [Google Earth Engine Code Editor](https://code.earthengine.google.com/) (requires a GEE account).
2. Create a new script and paste the contents of **`GEE_MorskieOko.js`**.
3. In the script:
   - Confirm the polygon/ROI matches Morskie Oko (or draw/import your own).
   - The script computes **water occurrence** and a **yearly open‑water area** time series from the GSW dataset.
4. Use the `Export` tasks already set in the script to produce:
   - `water_occurrence_2014_2024.tif` (occurrence raster)
   - `MorskieOko_Yearly_Water_Area.csv` (raw area series)
5. When the tasks finish, download the outputs and drop them into this repo alongside the existing examples.

### 2) Make figures locally (no GEE needed)
We provide **`make_figures.py`** which looks for the CSVs in the project folder and generates two charts:
- `occurrence_histogram.png` — pixel histogram from occurrence CSV
- `water_area_timeseries.png` — yearly area trend from `Yearly_Water_Area_clean.csv` (or `MorskieOko_Yearly_Water_Area.csv`)

**Setup once:**
```bash
python -m venv .venv
source .venv/bin/activate  # Windows: .venv\Scripts\activate
pip install -U pip matplotlib pandas
```

**Run:**
```bash
python make_figures.py
```
The script auto‑detects file names and column headers (see its docstrings).

### 3) Explore in QGIS (optional)
Open **`morskie_oko.qgz`** in QGIS ≥ 3.28.  
If a layer shows as missing, right‑click it and **Set Data Source…** to the corresponding file in this folder (e.g., `water_occurrence_2014_2024.tif`).

---

## 📁 File-by-file notes

- **`GEE_MorskieOko.js`** — Earth Engine code that reads **Global Surface Water** layers, clips to the ROI, and exports:
  - annual open‑water area as a CSV; and
  - pixel‑wise water **occurrence** as a GeoTIFF.
- **`Yearly_Water_Area_clean.csv`** — cleaned series of lake area per year (used by the plotting script).
- **`MorskieOko_Yearly_Water_Area.csv`** — raw export from GEE (kept for traceability).
- **`water_occurrence_2014_2024.tif`** — occurrence raster (0–100%).
- **`MorskieOko_Water_Occurrence.csv`** — occurrence as a flat table for quick inspection.
- **`occurrence_histogram.png`, `water_area_timeseries.png`** — quick‑look charts produced by `make_figures.py`.
- **`morskie_oko.qgz`** — QGIS project with predefined styles and extent.
- **`REPORT_Water_Scoring.docx` / `WaterSurfaceChanges_En.pptx`** — write‑up and slides for sharing results.

---

## 🧪 Reproducibility checklist

- GEE script runs “as is” with the default ROI.  
  Replace the ROI or AOI in `GEE_MorskieOko.js` to apply the workflow to a different lake.
- All figures can be recreated by running `make_figures.py` after placing CSVs in the project root.
- QGIS project opens without edits if the files keep their relative names/locations.

---

## 📌 Assumptions & caveats

- The **GSW dataset** detects *open water*; temporary snow/ice or shadows may influence detection in some years.  
- Yearly area values are **as reported by GEE exports**; cleaning steps are documented in `make_figures.py` comments.
- Occurrence is summarized for 2014–2024 in this bundle; extend the date span in GEE for other periods.

---

## 🙌 Acknowledgements

- Google Earth Engine team & the **Global Surface Water** dataset.
- Open‑source tools: **QGIS**, **pandas**, **matplotlib**.

---

## 📄 License

No explicit license file was included in the zip. If you plan to publish this project, please add a `LICENSE` (e.g., MIT) and a proper citation for the data sources.

---

## 💬 Questions

If anything doesn’t open or a path is broken, check that you kept the **file names** listed above and the **project structure** intact.  
Feel free to reach out with the exact error and we’ll help you get it running.