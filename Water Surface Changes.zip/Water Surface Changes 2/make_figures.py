#!/usr/bin/env python3
"""
make_figures.py
Reproduces the two key figures for the Morskie Oko analysis:
  1) Occurrence (%) histogram
  2) Annual water area (km²) time series

The script is robust to minor filename/column-name differences and will try fallbacks:
- For the histogram: prefer reading "MorskieOko_Occurrence.tif" (via rasterio). If rasterio
  is unavailable, it will try to read a CSV with occurrence values (e.g. "MorskieOko_Occurrence_stats.csv"
  or "MorskieOko_MappingLayers_Stats.csv").
- For the time series: it tries to detect 'year' and 'water area' columns in
  "Yearly_Water_Area_clean.csv" or similar files in the working directory.

Usage:
    python make_figures.py
Output:
    Occurrence_histogram_matplotlib.png
    Yearly_Water_Area_matplotlib.png
"""
import os
import sys
import glob
import math

import numpy as np
import matplotlib.pyplot as plt

def find_file(candidates):
    for c in candidates:
        if os.path.exists(c):
            return c
    # try loose pattern match
    for c in candidates:
        head, tail = os.path.split(c)
        pattern = tail.replace("Occurrence", "*Occurrence*").replace("Occurence", "*Occur*")
        for p in glob.glob(os.path.join(head or ".", pattern)):
            return p
    return None

def read_occurrence_values():
    """
    Returns a 1D numpy array of occurrence values in [0,100].
    Tries GeoTIFF via rasterio first; if not available/failed, tries CSV fallbacks.
    """
    tiff_candidates = [
        "MorskieOko_Occurrence.tif",
        "MorskieOko_Occurence.tif",
        "data/MorskieOko_Occurrence.tif",
        "outputs/MorskieOko_Occurrence.tif",
    ]
    tif_path = find_file(tiff_candidates)

    # Try raster route
    if tif_path is not None:
        try:
            import rasterio
            with rasterio.open(tif_path) as ds:
                arr = ds.read(1, masked=True)
                vals = np.asarray(arr.compressed(), dtype=float)
                # Clip to 0..100 if needed
                vals = vals[(vals >= 0) & (vals <= 100)]
                if vals.size > 0:
                    return vals
        except Exception as e:
            print(f"[warn] Could not read GeoTIFF '{tif_path}' via rasterio: {e}")

    # CSV fallbacks
    csv_candidates = [
        "MorskieOko_Occurrence_stats.csv",
        "MorskieOko_Occurence_stats.csv",
        "MorskieOko_MappingLayers_Stats.csv",
        "outputs/MorskieOko_Occurrence_stats.csv",
        "outputs/MorskieOko_MappingLayers_Stats.csv",
    ]
    for csv_path in csv_candidates:
        if os.path.exists(csv_path):
            try:
                import pandas as pd
                df = pd.read_csv(csv_path)
                # Find a column that looks like occurrence
                occ_col = None
                for col in df.columns:
                    lc = col.lower()
                    if "occ" in lc or "occurrence" in lc or "occurence" in lc:
                        occ_col = col
                        break
                if occ_col is None:
                    # If not found, fallback to first numeric column
                    num_cols = [c for c in df.columns if pd.api.types.is_numeric_dtype(df[c])]
                    if num_cols:
                        occ_col = num_cols[0]
                if occ_col:
                    vals = df[occ_col].to_numpy(dtype=float)
                    vals = vals[(vals >= 0) & (vals <= 100)]
                    if vals.size > 0:
                        return vals
            except Exception as e:
                print(f"[warn] Could not parse CSV '{csv_path}': {e}")
    raise RuntimeError("No occurrence data source found. Provide a GeoTIFF or a CSV with occurrence values.")

def plot_occurrence_histogram(values, out_path="Occurrence_histogram_matplotlib.png"):
    plt.figure(figsize=(12, 7))
    bins = np.arange(0, 101, 2)  # 0..100 step 2
    plt.hist(values, bins=bins)
    plt.title("Occurrence (%) — Histogram")
    plt.xlabel("Occurrence (%)")
    plt.ylabel("Pixel count")
    plt.grid(True, linestyle=":", linewidth=0.8, alpha=0.6)
    plt.tight_layout()
    plt.savefig(out_path, dpi=200)
    plt.close()
    print(f"[ok] Saved histogram -> {out_path}")

def read_yearly_series():
    """
    Returns (years, areas_km2).
    Tries Yearly_Water_Area_clean.csv or similar. Detects columns by name.
    """
    import pandas as pd
    candidates = [
        "Yearly_Water_Area_clean.csv",
        "MorskieOko_Yearly_Water_Area.csv",
        "outputs/Yearly_Water_Area_clean.csv",
        "outputs/MorskieOko_Yearly_Water_Area.csv",
    ]
    path = None
    for c in candidates:
        if os.path.exists(c):
            path = c
            break
    if path is None:
        # try any csv that looks relevant
        for p in glob.glob("*.csv"):
            if "water" in p.lower() and "area" in p.lower():
                path = p; break
    if path is None:
        raise RuntimeError("No yearly water area CSV found.")
    df = pd.read_csv(path)
    # guess columns
    year_col = None
    area_col = None
    for col in df.columns:
        lc = col.lower()
        if "year" in lc:
            year_col = col
        if ("water" in lc and "area" in lc) or ("km2" in lc) or ("km^2" in lc):
            area_col = col
    if year_col is None:
        # fallback: first column that looks integer-ish
        for col in df.columns:
            try:
                if np.all(np.isfinite(df[col])) and df[col].dropna().astype(int).equals(df[col].dropna().astype(float)):
                    year_col = col; break
            except Exception:
                pass
    if area_col is None:
        # fallback: first numeric col that's not year
        num_cols = [c for c in df.columns if pd.api.types.is_numeric_dtype(df[c])]
        for c in num_cols:
            if c != year_col:
                area_col = c; break
    if year_col is None or area_col is None:
        raise RuntimeError(f"Could not detect columns. Columns: {list(df.columns)}")
    years = df[year_col].to_numpy()
    areas = df[area_col].to_numpy(dtype=float)
    return years, areas, path, year_col, area_col

def plot_yearly_series(years, areas, out_path="Yearly_Water_Area_matplotlib.png"):
    plt.figure(figsize=(12, 7))
    plt.plot(years, areas, marker="o")
    plt.title("Morskie Oko — Annual Water Area (km²)")
    plt.xlabel("Year")
    plt.ylabel("Water Area (km²)")
    plt.grid(True, linestyle=":", linewidth=0.8, alpha=0.6)
    plt.tight_layout()
    plt.savefig(out_path, dpi=200)
    plt.close()
    print(f"[ok] Saved time series -> {out_path}")

def main():
    occ_vals = read_occurrence_values()
    plot_occurrence_histogram(occ_vals)

    years, areas, path, year_col, area_col = read_yearly_series()
    print(f"[info] Time series from '{path}' using columns year='{year_col}', area='{area_col}'")
    plot_yearly_series(years, areas)

if __name__ == "__main__":
    main()
