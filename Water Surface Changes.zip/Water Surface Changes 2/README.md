# Water Surface Changes — Morskie Oko (Reproducibility Guide)

This file provides a concise guide to **reproducing the project end‑to‑end**.
Data source: **JRC Global Surface Water v1.4 (GSW)** — Mapping Layers + Yearly History.

## 1) Required Files
- **GEE_MorskieOko.js** → Earth Engine script that performs all analyses and exports.
- **ROI_MorskieOko.geojson** → ROI polygon (you can upload to Assets or draw directly on the map).
- **Yearly_Water_Area_clean.csv** → Annual water area (km²) — cleaned.
- **MorskieOko_MappingLayers_Stats.csv** → Summary statistics for Occurrence & Change_abs (mean/std).
- **Figures**: `Occurrence_histogram.png`, `ChangeAbs_histogram.png`, `Yearly_Water_Area.png`, `Boxplots.png`
- (Optional) GeoTIFFs: `MorskieOko_Occurrence.tif`, `MorskieOko_ChangeAbs.tif`, `MorskieOko_waterClass_2020.tif`
- (Optional) Presentation: `Water Surface Changes.pptx`
- (Optional) QGIS project: `*.qgz`

## 2) Recommended Folder Structure
```
project/
├─ GEE_MorskieOko.js
├─ ROI_MorskieOko.geojson
├─ Yearly_Water_Area_clean.csv
├─ MorskieOko_MappingLayers_Stats.csv
├─ figures/
│  ├─ Occurrence_histogram.png
│  ├─ ChangeAbs_histogram.png
│  ├─ Yearly_Water_Area.png
│  └─ Boxplots.png
└─ data/ (optional)
   ├─ MorskieOko_Occurrence.tif
   ├─ MorskieOko_ChangeAbs.tif
   └─ MorskieOko_waterClass_2020.tif
```

## 3) Running in GEE (summary)
1. Go to **https://code.earthengine.google.com** → paste the content of `GEE_MorskieOko.js` or open it via `File ▸ Open`.
2. Two ways to set the ROI:
   - Draw a **Polygon** on the map and name it **`geometry`** (if it’s LinearRing, the script auto‑converts to Polygon).
   - Or upload **ROI_MorskieOko.geojson** as an **Asset**; the script can use it automatically (there’s also an auto‑ROI fallback).
3. Click **Run** → in the **Tasks** panel, click **Run** for:
   - **MorskieOko_Yearly_Water_Area** (CSV)
   - **MorskieOko_MappingLayers_Stats** (CSV)
   - (Optional) **MorskieOko_Occurrence**/**MorskieOko_ChangeAbs**/**MorskieOko_waterClass_2020** (GeoTIFF)
   - Destination folder: **Drive ▸ GEE_MorskieOko** (created automatically).

> In the export dialogs you’ll see: `scale=30`, `tileScale=4`, `maxPixels=1e13`.
> **Permanent water** threshold: `THRESH = 90` (you may lower to 80 if needed).

## 4) Outputs & Usage
- **Yearly_Water_Area_clean.csv** → Annual time series with columns `year, water_km2`.
- **MorskieOko_MappingLayers_Stats.csv** → Metrics `occ_mean, occ_stdDev, chg_mean, chg_stdDev, permanent_km2`.
- Figures can be inserted directly into slides. If you want to regenerate them, use Matplotlib (e.g., a `make_figures.py` or the provided notebook).

## 5) Notes
- **GSW** is pre‑processed; extra “noise removal / cloud mask” steps are unnecessary here.
- The earlier “Sentinel Hub + Python/sentinelhub” plan is **not required** for this project (GEE + GSW suffices).
- For **CRS**, `EPSG:4326` or `EPSG:3857` are both fine; GeoTIFFs open directly in QGIS.
- To persist the ROI as an asset (optional):
  ```js
  Export.table.toAsset({
    collection: ee.FeatureCollection([ee.Feature(geometry)]),
    description: 'MorskieOko_ROI_asset',
    assetId: 'users/<username>/MorskieOko_ROI'
  });
  ```

## 6) License/Citation
- Data: **JRC Global Surface Water v1.4** (European Commission, Joint Research Centre). Please include appropriate citations in your report.
