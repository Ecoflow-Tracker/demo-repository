import json
import random
from datetime import datetime, timedelta
import matplotlib.pyplot as plt
import numpy as np

class WaterPollutionAnalyzer:
    def __init__(self):
        self.data_points = []
        self.thresholds = {
            'ph_min': 6.5,
            'ph_max': 8.5,
            'oxygen_min': 5.0,
            'turbidity_max': 30.0,
            'temperature_max': 25.0
        }
    
    def generate_sample_data(self, days=30):
        """Generate sample water pollution data for testing"""
        base_date = datetime.now() - timedelta(days=days)
        
        for i in range(days):
            current_date = base_date + timedelta(days=i)
            
            # Simulate degrading water quality over time
            degradation_factor = i / days
            
            data_point = {
                'timestamp': current_date.isoformat(),
                'location': f"Station_{random.randint(1, 5)}",
                'ph': round(7.5 - (degradation_factor * 2) + random.uniform(-0.3, 0.3), 2),
                'dissolved_oxygen': round(8.0 - (degradation_factor * 4) + random.uniform(-0.5, 0.5), 2),
                'turbidity': round(10 + (degradation_factor * 40) + random.uniform(-5, 10), 2),
                'temperature': round(20 + (degradation_factor * 8) + random.uniform(-2, 3), 2),
                'conductivity': round(500 + (degradation_factor * 200) + random.uniform(-50, 100), 2),
                'nitrates': round(2 + (degradation_factor * 8) + random.uniform(-1, 2), 2),
                'phosphates': round(0.5 + (degradation_factor * 2) + random.uniform(-0.2, 0.5), 2)
            }
            
            self.data_points.append(data_point)
        
        print(f"Generated {len(self.data_points)} data points")
        return self.data_points
    
    def analyze_water_quality(self, data_point):
        """Analyze a single water quality measurement"""
        issues = []
        severity = "good"
        
        # pH Analysis
        if data_point['ph'] < self.thresholds['ph_min']:
            issues.append(f"pH too acidic: {data_point['ph']}")
            severity = "critical" if data_point['ph'] < 6.0 else "warning"
        elif data_point['ph'] > self.thresholds['ph_max']:
            issues.append(f"pH too alkaline: {data_point['ph']}")
            severity = "warning"
        
        # Dissolved Oxygen Analysis
        if data_point['dissolved_oxygen'] < self.thresholds['oxygen_min']:
            issues.append(f"Low oxygen levels: {data_point['dissolved_oxygen']} mg/L")
            severity = "critical" if data_point['dissolved_oxygen'] < 3.0 else "warning"
        
        # Turbidity Analysis
        if data_point['turbidity'] > self.thresholds['turbidity_max']:
            issues.append(f"High turbidity: {data_point['turbidity']} NTU")
            severity = "warning"
        
        # Temperature Analysis
        if data_point['temperature'] > self.thresholds['temperature_max']:
            issues.append(f"High temperature: {data_point['temperature']}°C")
            severity = "warning"
        
        return {
            'status': severity,
            'issues': issues,
            'timestamp': data_point['timestamp'],
            'location': data_point['location']
        }
    
    def generate_pollution_report(self):
        """Generate a comprehensive pollution report"""
        if not self.data_points:
            return "No data available for analysis"
        
        report = {
            'summary': {
                'total_measurements': len(self.data_points),
                'critical_alerts': 0,
                'warning_alerts': 0,
                'good_readings': 0
            },
            'trends': {},
            'alerts': []
        }
        
        # Analyze each data point
        for data_point in self.data_points:
            analysis = self.analyze_water_quality(data_point)
            
            if analysis['status'] == 'critical':
                report['summary']['critical_alerts'] += 1
                report['alerts'].append(analysis)
            elif analysis['status'] == 'warning':
                report['summary']['warning_alerts'] += 1
                report['alerts'].append(analysis)
            else:
                report['summary']['good_readings'] += 1
        
        # Calculate trends
        recent_data = self.data_points[-7:]  # Last 7 days
        older_data = self.data_points[-14:-7]  # Previous 7 days
        
        if len(recent_data) > 0 and len(older_data) > 0:
            recent_avg_ph = sum(d['ph'] for d in recent_data) / len(recent_data)
            older_avg_ph = sum(d['ph'] for d in older_data) / len(older_data)
            
            recent_avg_oxygen = sum(d['dissolved_oxygen'] for d in recent_data) / len(recent_data)
            older_avg_oxygen = sum(d['dissolved_oxygen'] for d in older_data) / len(older_data)
            
            report['trends'] = {
                'ph_trend': 'improving' if recent_avg_ph > older_avg_ph else 'declining',
                'oxygen_trend': 'improving' if recent_avg_oxygen > older_avg_oxygen else 'declining',
                'ph_change': round(recent_avg_ph - older_avg_ph, 2),
                'oxygen_change': round(recent_avg_oxygen - older_avg_oxygen, 2)
            }
        
        return report
    
    def create_visualization(self):
        """Create pollution trend visualizations"""
        if not self.data_points:
            print("No data available for visualization")
            return
        
        # Extract data for plotting
        dates = [datetime.fromisoformat(d['timestamp']) for d in self.data_points]
        ph_values = [d['ph'] for d in self.data_points]
        oxygen_values = [d['dissolved_oxygen'] for d in self.data_points]
        turbidity_values = [d['turbidity'] for d in self.data_points]
        
        # Create subplots
        fig, ((ax1, ax2), (ax3, ax4)) = plt.subplots(2, 2, figsize=(15, 10))
        fig.suptitle('Water Pollution Analysis Dashboard', fontsize=16, fontweight='bold')
        
        # pH Levels
        ax1.plot(dates, ph_values, 'b-', linewidth=2, label='pH Level')
        ax1.axhline(y=self.thresholds['ph_min'], color='r', linestyle='--', alpha=0.7, label='Min Safe pH')
        ax1.axhline(y=self.thresholds['ph_max'], color='r', linestyle='--', alpha=0.7, label='Max Safe pH')
        ax1.set_title('pH Levels Over Time')
        ax1.set_ylabel('pH')
        ax1.legend()
        ax1.grid(True, alpha=0.3)
        
        # Dissolved Oxygen
        ax2.plot(dates, oxygen_values, 'g-', linewidth=2, label='Dissolved Oxygen')
        ax2.axhline(y=self.thresholds['oxygen_min'], color='r', linestyle='--', alpha=0.7, label='Min Safe O₂')
        ax2.set_title('Dissolved Oxygen Levels')
        ax2.set_ylabel('mg/L')
        ax2.legend()
        ax2.grid(True, alpha=0.3)
        
        # Turbidity
        ax3.plot(dates, turbidity_values, 'orange', linewidth=2, label='Turbidity')
        ax3.axhline(y=self.thresholds['turbidity_max'], color='r', linestyle='--', alpha=0.7, label='Max Safe Turbidity')
        ax3.set_title('Water Turbidity')
        ax3.set_ylabel('NTU')
        ax3.legend()
        ax3.grid(True, alpha=0.3)
        
        # Water Quality Status Distribution
        statuses = []
        for data_point in self.data_points:
            analysis = self.analyze_water_quality(data_point)
            statuses.append(analysis['status'])
        
        status_counts = {status: statuses.count(status) for status in ['good', 'warning', 'critical']}
        colors = ['green', 'orange', 'red']
        ax4.pie(status_counts.values(), labels=status_counts.keys(), colors=colors, autopct='%1.1f%%')
        ax4.set_title('Water Quality Status Distribution')
        
        plt.tight_layout()
        plt.show()
        
        print("Visualization created successfully!")

def main():
    """Main function to demonstrate the water pollution analyzer"""
    print("🌊 Water Pollution Tracking System")
    print("=" * 40)
    
    # Initialize analyzer
    analyzer = WaterPollutionAnalyzer()
    
    # Generate sample data
    print("Generating sample pollution data...")
    analyzer.generate_sample_data(30)
    
    # Generate report
    print("\nGenerating pollution analysis report...")
    report = analyzer.generate_pollution_report()
    
    print(f"\n📊 POLLUTION ANALYSIS REPORT")
    print(f"Total Measurements: {report['summary']['total_measurements']}")
    print(f"Critical Alerts: {report['summary']['critical_alerts']}")
    print(f"Warning Alerts: {report['summary']['warning_alerts']}")
    print(f"Good Readings: {report['summary']['good_readings']}")
    
    if report['trends']:
        print(f"\n📈 TRENDS:")
        print(f"pH Trend: {report['trends']['ph_trend']} ({report['trends']['ph_change']:+.2f})")
        print(f"Oxygen Trend: {report['trends']['oxygen_trend']} ({report['trends']['oxygen_change']:+.2f} mg/L)")
    
    if report['alerts']:
        print(f"\n🚨 RECENT ALERTS:")
        for alert in report['alerts'][-5:]:  # Show last 5 alerts
            print(f"  {alert['status'].upper()}: {', '.join(alert['issues'])} at {alert['location']}")
    
    # Create visualization
    print("\nCreating pollution trend visualizations...")
    analyzer.create_visualization()
    
    # Export data
    print("\nExporting data to JSON...")
    with open('water_pollution_data.json', 'w') as f:
        json.dump({
            'data_points': analyzer.data_points,
            'report': report
        }, f, indent=2)
    
    print("✅ Analysis complete! Data exported to 'water_pollution_data.json'")

if __name__ == "__main__":
    main()
