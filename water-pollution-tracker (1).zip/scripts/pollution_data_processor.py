import csv
import json
from datetime import datetime
import statistics

class PollutionDataProcessor:
    """Process and analyze water pollution data from various sources"""
    
    def __init__(self):
        self.processed_data = []
        self.quality_standards = {
            'drinking_water': {
                'ph_min': 6.5, 'ph_max': 8.5,
                'turbidity_max': 1.0,
                'nitrates_max': 10.0,
                'phosphates_max': 0.1
            },
            'aquatic_life': {
                'ph_min': 6.0, 'ph_max': 9.0,
                'dissolved_oxygen_min': 5.0,
                'temperature_max': 28.0
            }
        }
    
    def load_csv_data(self, filename):
        """Load pollution data from CSV file"""
        try:
            with open(filename, 'r') as file:
                reader = csv.DictReader(file)
                data = list(reader)
                print(f"Loaded {len(data)} records from {filename}")
                return data
        except FileNotFoundError:
            print(f"File {filename} not found. Creating sample data...")
            return self.create_sample_csv_data(filename)
    
    def create_sample_csv_data(self, filename):
        """Create sample CSV data for demonstration"""
        sample_data = [
            {
                'timestamp': '2024-01-01T10:00:00',
                'location': 'River_Station_A',
                'ph': '7.2',
                'dissolved_oxygen': '8.5',
                'turbidity': '12.3',
                'temperature': '15.2',
                'nitrates': '2.1',
                'phosphates': '0.3'
            },
            {
                'timestamp': '2024-01-02T10:00:00',
                'location': 'River_Station_A',
                'ph': '6.8',
                'dissolved_oxygen': '7.8',
                'turbidity': '18.7',
                'temperature': '16.1',
                'nitrates': '3.2',
                'phosphates': '0.4'
            },
            {
                'timestamp': '2024-01-03T10:00:00',
                'location': 'Lake_Station_B',
                'ph': '6.5',
                'dissolved_oxygen': '6.2',
                'turbidity': '25.1',
                'temperature': '18.3',
                'nitrates': '4.8',
                'phosphates': '0.6'
            }
        ]
        
        # Write sample data to CSV
        with open(filename, 'w', newline='') as file:
            fieldnames = sample_data[0].keys()
            writer = csv.DictWriter(file, fieldnames=fieldnames)
            writer.writeheader()
            writer.writerows(sample_data)
        
        print(f"Created sample CSV file: {filename}")
        return sample_data
    
    def process_data(self, raw_data):
        """Process and clean raw pollution data"""
        processed = []
        
        for record in raw_data:
            try:
                processed_record = {
                    'timestamp': datetime.fromisoformat(record['timestamp'].replace('Z', '+00:00')),
                    'location': record['location'],
                    'ph': float(record['ph']),
                    'dissolved_oxygen': float(record['dissolved_oxygen']),
                    'turbidity': float(record['turbidity']),
                    'temperature': float(record['temperature']),
                    'nitrates': float(record.get('nitrates', 0)),
                    'phosphates': float(record.get('phosphates', 0))
                }
                
                # Add quality assessment
                processed_record['quality_score'] = self.calculate_quality_score(processed_record)
                processed_record['compliance'] = self.check_compliance(processed_record)
                
                processed.append(processed_record)
                
            except (ValueError, KeyError) as e:
                print(f"Error processing record: {e}")
                continue
        
        self.processed_data = processed
        print(f"Successfully processed {len(processed)} records")
        return processed
    
    def calculate_quality_score(self, record):
        """Calculate overall water quality score (0-100)"""
        score = 100
        
        # pH scoring
        if 6.5 <= record['ph'] <= 8.5:
            ph_score = 100
        elif 6.0 <= record['ph'] <= 9.0:
            ph_score = 75
        else:
            ph_score = 25
        
        # Oxygen scoring
        if record['dissolved_oxygen'] >= 8.0:
            oxygen_score = 100
        elif record['dissolved_oxygen'] >= 5.0:
            oxygen_score = 75
        else:
            oxygen_score = 25
        
        # Turbidity scoring
        if record['turbidity'] <= 10:
            turbidity_score = 100
        elif record['turbidity'] <= 30:
            turbidity_score = 75
        else:
            turbidity_score = 25
        
        # Calculate weighted average
        quality_score = (ph_score * 0.3 + oxygen_score * 0.4 + turbidity_score * 0.3)
        return round(quality_score, 1)
    
    def check_compliance(self, record):
        """Check compliance with water quality standards"""
        drinking_compliant = True
        aquatic_compliant = True
        
        # Check drinking water standards
        dw_std = self.quality_standards['drinking_water']
        if not (dw_std['ph_min'] <= record['ph'] <= dw_std['ph_max']):
            drinking_compliant = False
        if record['turbidity'] > dw_std['turbidity_max']:
            drinking_compliant = False
        if record['nitrates'] > dw_std['nitrates_max']:
            drinking_compliant = False
        if record['phosphates'] > dw_std['phosphates_max']:
            drinking_compliant = False
        
        # Check aquatic life standards
        al_std = self.quality_standards['aquatic_life']
        if not (al_std['ph_min'] <= record['ph'] <= al_std['ph_max']):
            aquatic_compliant = False
        if record['dissolved_oxygen'] < al_std['dissolved_oxygen_min']:
            aquatic_compliant = False
        if record['temperature'] > al_std['temperature_max']:
            aquatic_compliant = False
        
        return {
            'drinking_water': drinking_compliant,
            'aquatic_life': aquatic_compliant
        }
    
    def generate_statistics(self):
        """Generate statistical summary of the data"""
        if not self.processed_data:
            return "No processed data available"
        
        stats = {}
        parameters = ['ph', 'dissolved_oxygen', 'turbidity', 'temperature', 'quality_score']
        
        for param in parameters:
            values = [record[param] for record in self.processed_data]
            stats[param] = {
                'mean': round(statistics.mean(values), 2),
                'median': round(statistics.median(values), 2),
                'min': round(min(values), 2),
                'max': round(max(values), 2),
                'std_dev': round(statistics.stdev(values) if len(values) > 1 else 0, 2)
            }
        
        # Compliance statistics
        drinking_compliant = sum(1 for r in self.processed_data if r['compliance']['drinking_water'])
        aquatic_compliant = sum(1 for r in self.processed_data if r['compliance']['aquatic_life'])
        
        stats['compliance'] = {
            'drinking_water_compliance_rate': round(drinking_compliant / len(self.processed_data) * 100, 1),
            'aquatic_life_compliance_rate': round(aquatic_compliant / len(self.processed_data) * 100, 1)
        }
        
        return stats
    
    def export_processed_data(self, filename='processed_pollution_data.json'):
        """Export processed data to JSON"""
        export_data = {
            'metadata': {
                'total_records': len(self.processed_data),
                'processing_date': datetime.now().isoformat(),
                'quality_standards': self.quality_standards
            },
            'statistics': self.generate_statistics(),
            'data': []
        }
        
        # Convert datetime objects to strings for JSON serialization
        for record in self.processed_data:
            json_record = record.copy()
            json_record['timestamp'] = record['timestamp'].isoformat()
            export_data['data'].append(json_record)
        
        with open(filename, 'w') as f:
            json.dump(export_data, f, indent=2)
        
        print(f"Processed data exported to {filename}")
        return filename

def main():
    """Main function to demonstrate data processing"""
    print("🔬 Water Pollution Data Processor")
    print("=" * 40)
    
    processor = PollutionDataProcessor()
    
    # Load and process data
    print("Loading pollution data...")
    raw_data = processor.load_csv_data('water_samples.csv')
    
    print("Processing data...")
    processed_data = processor.process_data(raw_data)
    
    # Generate statistics
    print("Generating statistics...")
    stats = processor.generate_statistics()
    
    print("\n📊 DATA STATISTICS:")
    for param, values in stats.items():
        if param != 'compliance':
            print(f"{param.upper()}: Mean={values['mean']}, Range=[{values['min']}-{values['max']}]")
    
    print(f"\n✅ COMPLIANCE RATES:")
    print(f"Drinking Water Standards: {stats['compliance']['drinking_water_compliance_rate']}%")
    print(f"Aquatic Life Standards: {stats['compliance']['aquatic_life_compliance_rate']}%")
    
    # Export processed data
    print("\nExporting processed data...")
    export_file = processor.export_processed_data()
    
    print(f"✅ Processing complete! Check {export_file} for results.")

if __name__ == "__main__":
    main()
