import json
import random
import datetime
from typing import Dict, List

def generate_sample_pollution_data(days: int = 30) -> List[Dict]:
    """
    Generate sample water pollution data for testing EcoFlow Tracker
    """
    data = []
    base_date = datetime.datetime.now() - datetime.timedelta(days=days)
    
    # Define pollution scenarios
    scenarios = {
        'clean_water': {
            'ph': (7.0, 8.0),
            'oxygen': (7.0, 9.0),
            'turbidity': (5, 15),
            'temperature': (18, 25),
            'nitrates': (0, 3),
            'phosphates': (0, 0.05)
        },
        'moderate_pollution': {
            'ph': (6.2, 7.5),
            'oxygen': (4.5, 7.0),
            'turbidity': (15, 30),
            'temperature': (20, 28),
            'nitrates': (3, 8),
            'phosphates': (0.05, 0.12)
        },
        'heavy_pollution': {
            'ph': (5.0, 6.5),
            'oxygen': (2.0, 5.0),
            'turbidity': (30, 60),
            'temperature': (22, 32),
            'nitrates': (8, 20),
            'phosphates': (0.12, 0.3)
        }
    }
    
    locations = [
        {"id": "RIVER_DELTA", "name": "River Delta Station", "scenario": "heavy_pollution"},
        {"id": "INDUSTRIAL", "name": "Industrial Zone Monitor", "scenario": "moderate_pollution"},
        {"id": "RESIDENTIAL", "name": "Residential Area Sensor", "scenario": "clean_water"},
        {"id": "UPSTREAM", "name": "Upstream Control Point", "scenario": "clean_water"}
    ]
    
    for day in range(days):
        current_date = base_date + datetime.timedelta(days=day)
        
        for location in locations:
            scenario = scenarios[location['scenario']]
            
            # Add some temporal variation (pollution gets worse over time for some locations)
            pollution_factor = 1.0
            if location['scenario'] == 'heavy_pollution':
                pollution_factor = 1.0 + (day / days) * 0.5  # Gets 50% worse over time
            
            reading = {
                'station_id': location['id'],
                'station_name': location['name'],
                'timestamp': current_date.isoformat(),
                'date': current_date.strftime('%Y-%m-%d'),
                'readings': {}
            }
            
            # Generate readings with some random variation
            for param, (min_val, max_val) in scenario.items():
                if param in ['ph', 'oxygen']:
                    # For pH and oxygen, lower values indicate more pollution
                    base_value = random.uniform(min_val, max_val)
                    if param == 'ph':
                        reading['readings'][param] = max(4.0, base_value / pollution_factor)
                    else:
                        reading['readings'][param] = max(1.0, base_value / pollution_factor)
                else:
                    # For other parameters, higher values indicate more pollution
                    base_value = random.uniform(min_val, max_val)
                    reading['readings'][param] = base_value * pollution_factor
            
            # Add some measurement noise
            for param in reading['readings']:
                noise = random.uniform(-0.1, 0.1)
                reading['readings'][param] = max(0, reading['readings'][param] + noise)
                reading['readings'][param] = round(reading['readings'][param], 2)
            
            data.append(reading)
    
    return data

def save_to_csv(data: List[Dict], filename: str):
    """Save pollution data to CSV format"""
    import csv
    
    if not data:
        return
    
    fieldnames = ['station_id', 'station_name', 'timestamp', 'date'] + list(data[0]['readings'].keys())
    
    with open(filename, 'w', newline='') as csvfile:
        writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
        writer.writeheader()
        
        for record in data:
            row = {
                'station_id': record['station_id'],
                'station_name': record['station_name'],
                'timestamp': record['timestamp'],
                'date': record['date']
            }
            row.update(record['readings'])
            writer.writerow(row)
    
    print(f"✅ Saved {len(data)} records to {filename}")

def save_to_json(data: List[Dict], filename: str):
    """Save pollution data to JSON format"""
    with open(filename, 'w') as jsonfile:
        json.dump(data, jsonfile, indent=2)
    
    print(f"✅ Saved {len(data)} records to {filename}")

def generate_alert_conditions(data: List[Dict]) -> List[Dict]:
    """Generate alert conditions based on pollution thresholds"""
    alerts = []
    
    thresholds = {
        'ph': {'min': 6.5, 'max': 8.5},
        'oxygen': {'min': 5.0, 'max': 15.0},
        'turbidity': {'min': 0, 'max': 25},
        'temperature': {'min': 0, 'max': 30},
        'nitrates': {'min': 0, 'max': 10},
        'phosphates': {'min': 0, 'max': 0.1}
    }
    
    for record in data:
        for param, value in record['readings'].items():
            if param in thresholds:
                threshold = thresholds[param]
                
                if value < threshold['min'] or value > threshold['max']:
                    severity = 'Critical' if (
                        (param == 'ph' and (value < 5.5 or value > 9.0)) or
                        (param == 'oxygen' and value < 3.0) or
                        (param == 'turbidity' and value > 40) or
                        (param == 'nitrates' and value > 15) or
                        (param == 'phosphates' and value > 0.2)
                    ) else 'Warning'
                    
                    alerts.append({
                        'station_id': record['station_id'],
                        'station_name': record['station_name'],
                        'timestamp': record['timestamp'],
                        'parameter': param,
                        'value': value,
                        'threshold_min': threshold['min'],
                        'threshold_max': threshold['max'],
                        'severity': severity,
                        'message': f"{param.title()} level {severity.lower()} at {record['station_name']}: {value}"
                    })
    
    return alerts

def main():
    """Generate sample pollution data for EcoFlow Tracker"""
    print("🌊 EcoFlow Tracker - Pollution Data Generator")
    print("=" * 50)
    
    # Generate 30 days of sample data
    print("📊 Generating 30 days of sample pollution data...")
    pollution_data = generate_sample_pollution_data(30)
    
    # Save data in multiple formats
    save_to_csv(pollution_data, 'ecoflow_pollution_data.csv')
    save_to_json(pollution_data, 'ecoflow_pollution_data.json')
    
    # Generate alerts
    print("\n⚠️  Analyzing data for alert conditions...")
    alerts = generate_alert_conditions(pollution_data)
    
    if alerts:
        save_to_json(alerts, 'ecoflow_alerts.json')
        
        # Show summary of alerts
        critical_alerts = [a for a in alerts if a['severity'] == 'Critical']
        warning_alerts = [a for a in alerts if a['severity'] == 'Warning']
        
        print(f"🚨 Generated {len(critical_alerts)} critical alerts")
        print(f"⚠️  Generated {len(warning_alerts)} warning alerts")
        
        # Show recent critical alerts
        if critical_alerts:
            print("\n🚨 Recent Critical Alerts:")
            for alert in critical_alerts[-5:]:  # Show last 5
                print(f"   - {alert['message']}")
    else:
        print("✅ No alerts generated - all readings within safe limits")
    
    # Generate summary statistics
    print(f"\n📈 Data Summary:")
    print(f"   Total readings: {len(pollution_data)}")
    print(f"   Monitoring stations: {len(set(r['station_id'] for r in pollution_data))}")
    print(f"   Date range: {pollution_data[0]['date']} to {pollution_data[-1]['date']}")
    
    print("\n✅ Sample data generation complete!")
    print("   Files created:")
    print("   - ecoflow_pollution_data.csv")
    print("   - ecoflow_pollution_data.json")
    if alerts:
        print("   - ecoflow_alerts.json")

if __name__ == "__main__":
    main()
