import json
import csv
import datetime
import random
import matplotlib.pyplot as plt
import numpy as np
from typing import Dict, List, Optional

class WaterQualityMonitor:
    """
    EcoFlow Tracker - Water Pollution Monitoring System
    Analyzes water quality parameters and generates pollution reports
    """
    
    def __init__(self):
        self.monitoring_stations = {}
        self.quality_standards = {
            'ph': {'min': 6.5, 'max': 8.5, 'unit': 'pH'},
            'oxygen': {'min': 5.0, 'max': 15.0, 'unit': 'mg/L'},
            'turbidity': {'min': 0, 'max': 25, 'unit': 'NTU'},
            'temperature': {'min': 0, 'max': 30, 'unit': '°C'},
            'nitrates': {'min': 0, 'max': 10, 'unit': 'mg/L'},
            'phosphates': {'min': 0, 'max': 0.1, 'unit': 'mg/L'}
        }
    
    def add_monitoring_station(self, station_id: str, name: str, location: Dict[str, float]):
        """Add a new water monitoring station"""
        self.monitoring_stations[station_id] = {
            'name': name,
            'location': location,
            'readings': [],
            'status': 'active'
        }
        print(f"✅ Added monitoring station: {name} ({station_id})")
    
    def record_reading(self, station_id: str, readings: Dict[str, float], timestamp: Optional[str] = None):
        """Record water quality readings for a station"""
        if station_id not in self.monitoring_stations:
            print(f"❌ Station {station_id} not found")
            return False
        
        if timestamp is None:
            timestamp = datetime.datetime.now().isoformat()
        
        reading_data = {
            'timestamp': timestamp,
            'readings': readings,
            'quality_score': self.calculate_quality_score(readings)
        }
        
        self.monitoring_stations[station_id]['readings'].append(reading_data)
        print(f"📊 Recorded reading for {self.monitoring_stations[station_id]['name']}")
        return True
    
    def calculate_quality_score(self, readings: Dict[str, float]) -> float:
        """Calculate overall water quality score (0-100)"""
        total_score = 0
        parameter_count = 0
        
        for param, value in readings.items():
            if param in self.quality_standards:
                standards = self.quality_standards[param]
                
                # Calculate parameter score based on how close to optimal range
                if standards['min'] <= value <= standards['max']:
                    score = 100  # Perfect score within range
                else:
                    # Penalty for being outside range
                    if value < standards['min']:
                        deviation = (standards['min'] - value) / standards['min']
                    else:
                        deviation = (value - standards['max']) / standards['max']
                    
                    score = max(0, 100 - (deviation * 100))
                
                total_score += score
                parameter_count += 1
        
        return total_score / parameter_count if parameter_count > 0 else 0
    
    def get_pollution_status(self, quality_score: float) -> str:
        """Determine pollution status based on quality score"""
        if quality_score >= 80:
            return "Good"
        elif quality_score >= 60:
            return "Moderate"
        elif quality_score >= 40:
            return "Poor"
        else:
            return "Critical"
    
    def generate_alerts(self, station_id: str) -> List[Dict]:
        """Generate alerts for water quality violations"""
        alerts = []
        
        if station_id not in self.monitoring_stations:
            return alerts
        
        station = self.monitoring_stations[station_id]
        if not station['readings']:
            return alerts
        
        latest_reading = station['readings'][-1]
        readings = latest_reading['readings']
        
        for param, value in readings.items():
            if param in self.quality_standards:
                standards = self.quality_standards[param]
                
                if value < standards['min'] or value > standards['max']:
                    severity = "Critical" if latest_reading['quality_score'] < 40 else "Warning"
                    alerts.append({
                        'station': station['name'],
                        'parameter': param,
                        'value': value,
                        'expected_range': f"{standards['min']}-{standards['max']} {standards['unit']}",
                        'severity': severity,
                        'timestamp': latest_reading['timestamp']
                    })
        
        return alerts
    
    def export_data(self, station_id: str, filename: str):
        """Export station data to CSV"""
        if station_id not in self.monitoring_stations:
            print(f"❌ Station {station_id} not found")
            return
        
        station = self.monitoring_stations[station_id]
        
        with open(filename, 'w', newline='') as csvfile:
            fieldnames = ['timestamp', 'quality_score'] + list(self.quality_standards.keys())
            writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
            
            writer.writeheader()
            for reading in station['readings']:
                row = {
                    'timestamp': reading['timestamp'],
                    'quality_score': reading['quality_score']
                }
                row.update(reading['readings'])
                writer.writerow(row)
        
        print(f"📁 Data exported to {filename}")
    
    def visualize_trends(self, station_id: str):
        """Create visualization of water quality trends"""
        if station_id not in self.monitoring_stations:
            print(f"❌ Station {station_id} not found")
            return
        
        station = self.monitoring_stations[station_id]
        readings = station['readings']
        
        if len(readings) < 2:
            print("❌ Not enough data for visualization")
            return
        
        # Extract data for plotting
        timestamps = [datetime.datetime.fromisoformat(r['timestamp']) for r in readings]
        quality_scores = [r['quality_score'] for r in readings]
        
        # Create subplots
        fig, ((ax1, ax2), (ax3, ax4)) = plt.subplots(2, 2, figsize=(15, 10))
        fig.suptitle(f'EcoFlow Tracker - {station["name"]} Water Quality Analysis', fontsize=16)
        
        # Quality Score Trend
        ax1.plot(timestamps, quality_scores, 'b-', linewidth=2, marker='o')
        ax1.set_title('Overall Quality Score')
        ax1.set_ylabel('Quality Score (0-100)')
        ax1.grid(True, alpha=0.3)
        ax1.axhline(y=80, color='g', linestyle='--', alpha=0.7, label='Good')
        ax1.axhline(y=60, color='y', linestyle='--', alpha=0.7, label='Moderate')
        ax1.axhline(y=40, color='r', linestyle='--', alpha=0.7, label='Poor')
        ax1.legend()
        
        # pH Levels
        ph_values = [r['readings'].get('ph', 0) for r in readings]
        ax2.plot(timestamps, ph_values, 'g-', linewidth=2, marker='s')
        ax2.set_title('pH Levels')
        ax2.set_ylabel('pH')
        ax2.grid(True, alpha=0.3)
        ax2.axhline(y=6.5, color='r', linestyle='--', alpha=0.7, label='Min Safe')
        ax2.axhline(y=8.5, color='r', linestyle='--', alpha=0.7, label='Max Safe')
        ax2.legend()
        
        # Oxygen Levels
        oxygen_values = [r['readings'].get('oxygen', 0) for r in readings]
        ax3.plot(timestamps, oxygen_values, 'c-', linewidth=2, marker='^')
        ax3.set_title('Dissolved Oxygen')
        ax3.set_ylabel('Oxygen (mg/L)')
        ax3.grid(True, alpha=0.3)
        ax3.axhline(y=5.0, color='r', linestyle='--', alpha=0.7, label='Min Safe')
        ax3.legend()
        
        # Turbidity
        turbidity_values = [r['readings'].get('turbidity', 0) for r in readings]
        ax4.plot(timestamps, turbidity_values, 'm-', linewidth=2, marker='d')
        ax4.set_title('Turbidity Levels')
        ax4.set_ylabel('Turbidity (NTU)')
        ax4.grid(True, alpha=0.3)
        ax4.axhline(y=25, color='r', linestyle='--', alpha=0.7, label='Max Safe')
        ax4.legend()
        
        plt.tight_layout()
        plt.show()
        print(f"📈 Generated visualization for {station['name']}")

def simulate_monitoring_data():
    """Simulate real-time water monitoring data"""
    monitor = WaterQualityMonitor()
    
    # Add monitoring stations
    stations = [
        ("RIVER_DELTA", "River Delta Station", {"lat": 40.7128, "lng": -74.0060}),
        ("INDUSTRIAL_ZONE", "Industrial Zone Monitor", {"lat": 40.7589, "lng": -73.9851}),
        ("RESIDENTIAL", "Residential Area Sensor", {"lat": 40.6782, "lng": -73.9442}),
        ("UPSTREAM", "Upstream Control Point", {"lat": 40.8176, "lng": -73.9782})
    ]
    
    for station_id, name, location in stations:
        monitor.add_monitoring_station(station_id, name, location)
    
    # Simulate 30 days of readings
    print("\n🔄 Simulating 30 days of water quality data...")
    
    for day in range(30):
        for station_id, _, _ in stations:
            # Simulate degrading water quality over time for some stations
            base_quality = 90 - (day * 2) if station_id == "RIVER_DELTA" else 85 - (day * 0.5)
            
            readings = {
                'ph': max(5.0, 7.2 - (day * 0.05) + random.uniform(-0.2, 0.2)),
                'oxygen': max(2.0, 8.5 - (day * 0.1) + random.uniform(-0.5, 0.5)),
                'turbidity': min(50, 10 + (day * 1.2) + random.uniform(-2, 5)),
                'temperature': 20 + random.uniform(-3, 8),
                'nitrates': random.uniform(0, 15),
                'phosphates': random.uniform(0, 0.2)
            }
            
            timestamp = (datetime.datetime.now() - datetime.timedelta(days=30-day)).isoformat()
            monitor.record_reading(station_id, readings, timestamp)
    
    return monitor

def main():
    """Main function to demonstrate EcoFlow Tracker functionality"""
    print("🌊 EcoFlow Tracker - Water Pollution Monitoring System")
    print("=" * 60)
    
    # Create monitoring system with simulated data
    monitor = simulate_monitoring_data()
    
    print("\n📊 Current Station Status:")
    print("-" * 40)
    
    for station_id, station in monitor.monitoring_stations.items():
        if station['readings']:
            latest = station['readings'][-1]
            quality_score = latest['quality_score']
            status = monitor.get_pollution_status(quality_score)
            
            print(f"🏭 {station['name']}")
            print(f"   Quality Score: {quality_score:.1f}/100 ({status})")
            print(f"   Latest Reading: {latest['timestamp'][:10]}")
            
            # Show alerts
            alerts = monitor.generate_alerts(station_id)
            if alerts:
                print(f"   ⚠️  {len(alerts)} Alert(s):")
                for alert in alerts[:2]:  # Show first 2 alerts
                    print(f"      - {alert['parameter']}: {alert['value']:.2f} {alert['severity']}")
            else:
                print("   ✅ No alerts")
            print()
    
    # Export data for the most problematic station
    print("📁 Exporting data for River Delta Station...")
    monitor.export_data("RIVER_DELTA", "river_delta_pollution_data.csv")
    
    # Generate visualization
    print("\n📈 Generating trend analysis...")
    monitor.visualize_trends("RIVER_DELTA")
    
    # Generate comprehensive report
    print("\n📋 Water Quality Summary Report")
    print("=" * 50)
    
    total_stations = len(monitor.monitoring_stations)
    critical_stations = 0
    
    for station_id, station in monitor.monitoring_stations.items():
        if station['readings']:
            latest_score = station['readings'][-1]['quality_score']
            if latest_score < 40:
                critical_stations += 1
    
    print(f"Total Monitoring Stations: {total_stations}")
    print(f"Stations in Critical Condition: {critical_stations}")
    print(f"System Health: {((total_stations - critical_stations) / total_stations * 100):.1f}%")
    
    if critical_stations > 0:
        print("\n🚨 IMMEDIATE ACTION REQUIRED:")
        print("   - Deploy emergency response teams")
        print("   - Increase monitoring frequency")
        print("   - Investigate pollution sources")

if __name__ == "__main__":
    main()
