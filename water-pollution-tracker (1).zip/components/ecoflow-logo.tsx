export function EcoFlowLogo({ className = "" }: { className?: string }) {
  return (
    <div className={`flex items-center space-x-3 ${className}`}>
      <div className="relative">
        <svg
          width="40"
          height="40"
          viewBox="0 0 40 40"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
          className="text-primary"
        >
          {/* Water drop shape */}
          <path
            d="M20 4C20 4 12 12 12 20C12 24.4183 15.5817 28 20 28C24.4183 28 28 24.4183 28 20C28 12 20 4 20 4Z"
            fill="currentColor"
            className="opacity-80"
          />
          {/* Flow lines */}
          <path
            d="M8 32C8 32 12 30 16 32C20 34 24 30 28 32C32 34 36 32 36 32"
            stroke="currentColor"
            strokeWidth="2"
            strokeLinecap="round"
            className="opacity-60"
          />
          <path
            d="M6 36C6 36 10 34 14 36C18 38 22 34 26 36C30 38 34 36 34 36"
            stroke="currentColor"
            strokeWidth="1.5"
            strokeLinecap="round"
            className="opacity-40"
          />
          {/* Center dot */}
          <circle cx="20" cy="20" r="3" fill="white" className="opacity-90" />
        </svg>
      </div>
      <div>
        <h1 className="text-2xl font-bold text-foreground tracking-tight">
          Eco<span className="text-primary">Flow</span>
        </h1>
        <p className="text-sm text-muted-foreground font-medium">Tracker</p>
      </div>
    </div>
  )
}
