"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, BarChart, Bar } from "recharts"
import { Search, Droplets, AlertTriangle, TrendingUp, MapPin, Calendar } from "lucide-react"
import { EcoFlowLogo } from "@/components/ecoflow-logo"

// Mock data for demonstration
const pollutionData = [
  { date: "2024-01", ph: 7.2, oxygen: 8.5, turbidity: 12, temperature: 15.2 },
  { date: "2024-02", ph: 6.8, oxygen: 7.8, turbidity: 18, temperature: 16.1 },
  { date: "2024-03", ph: 6.5, oxygen: 6.2, turbidity: 25, temperature: 18.3 },
  { date: "2024-04", ph: 6.1, oxygen: 5.8, turbidity: 32, temperature: 20.5 },
  { date: "2024-05", ph: 5.9, oxygen: 4.9, turbidity: 38, temperature: 22.1 },
  { date: "2024-06", ph: 5.7, oxygen: 4.2, turbidity: 45, temperature: 24.8 },
]

const locations = [
  { id: 1, name: "River Delta Station", status: "critical", ph: 5.7, oxygen: 4.2 },
  { id: 2, name: "Industrial Zone Monitor", status: "warning", ph: 6.1, oxygen: 5.8 },
  { id: 3, name: "Residential Area Sensor", status: "good", ph: 7.1, oxygen: 8.1 },
  { id: 4, name: "Upstream Control Point", status: "good", ph: 7.3, oxygen: 8.7 },
]

const alerts = [
  { id: 1, type: "critical", message: "pH levels critically low at River Delta Station", time: "2 hours ago" },
  { id: 2, type: "warning", message: "Oxygen depletion detected in Industrial Zone", time: "4 hours ago" },
  { id: 3, type: "info", message: "New monitoring station online at Residential Area", time: "1 day ago" },
]

export default function WaterPollutionTracker() {
  const [searchTerm, setSearchTerm] = useState("")
  const [selectedLocation, setSelectedLocation] = useState(locations[0])

  const getStatusColor = (status: string) => {
    switch (status) {
      case "critical":
        return "bg-destructive text-destructive-foreground"
      case "warning":
        return "bg-secondary text-secondary-foreground"
      case "good":
        return "bg-primary text-primary-foreground"
      default:
        return "bg-muted text-muted-foreground"
    }
  }

  const getAlertIcon = (type: string) => {
    switch (type) {
      case "critical":
        return <AlertTriangle className="h-4 w-4 text-destructive" />
      case "warning":
        return <AlertTriangle className="h-4 w-4 text-secondary" />
      default:
        return <TrendingUp className="h-4 w-4 text-primary" />
    }
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border bg-card">
        <div className="container mx-auto px-4 py-6">
          <div className="flex items-center justify-between">
            {/* EcoFlow Tracker logo */}
            <EcoFlowLogo />
            <div className="flex items-center space-x-4">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="Search locations..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10 w-64"
                />
              </div>
              <Button variant="outline">
                <Calendar className="h-4 w-4 mr-2" />
                Export Report
              </Button>
            </div>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
          {/* Sidebar */}
          <div className="lg:col-span-1 space-y-6">
            {/* Quick Stats */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">System Overview</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex justify-between items-center">
                  <span className="text-sm text-muted-foreground">Active Sensors</span>
                  <Badge variant="secondary">24</Badge>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-sm text-muted-foreground">Critical Alerts</span>
                  <Badge className="bg-destructive text-destructive-foreground">3</Badge>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-sm text-muted-foreground">Data Points Today</span>
                  <Badge variant="outline">1,247</Badge>
                </div>
              </CardContent>
            </Card>

            {/* Monitoring Locations */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Monitoring Locations</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                {locations.map((location) => (
                  <div
                    key={location.id}
                    className={`p-3 rounded-lg border cursor-pointer transition-colors ${
                      selectedLocation.id === location.id ? "bg-accent text-accent-foreground" : "hover:bg-muted"
                    }`}
                    onClick={() => setSelectedLocation(location)}
                  >
                    <div className="flex items-center justify-between mb-2">
                      <span className="font-medium text-sm">{location.name}</span>
                      <Badge className={getStatusColor(location.status)} variant="secondary">
                        {location.status}
                      </Badge>
                    </div>
                    <div className="flex items-center space-x-2 text-xs text-muted-foreground">
                      <MapPin className="h-3 w-3" />
                      <span>
                        pH: {location.ph} | O₂: {location.oxygen}mg/L
                      </span>
                    </div>
                  </div>
                ))}
              </CardContent>
            </Card>
          </div>

          {/* Main Content */}
          <div className="lg:col-span-3 space-y-6">
            {/* Alerts */}
            <div className="space-y-3">
              <h2 className="text-xl font-semibold text-foreground">Recent Alerts</h2>
              {alerts.map((alert) => (
                <Alert key={alert.id} className="border-l-4 border-l-primary">
                  <div className="flex items-start space-x-3">
                    {getAlertIcon(alert.type)}
                    <div className="flex-1">
                      <AlertTitle className="text-sm font-medium">{alert.message}</AlertTitle>
                      <AlertDescription className="text-xs text-muted-foreground mt-1">{alert.time}</AlertDescription>
                    </div>
                  </div>
                </Alert>
              ))}
            </div>

            {/* Data Visualization */}
            <Card>
              <CardHeader>
                <CardTitle>Water Quality Trends</CardTitle>
                <CardDescription>Monitoring data for {selectedLocation.name}</CardDescription>
              </CardHeader>
              <CardContent>
                <Tabs defaultValue="trends" className="w-full">
                  <TabsList className="grid w-full grid-cols-2">
                    <TabsTrigger value="trends">Pollution Trends</TabsTrigger>
                    <TabsTrigger value="comparison">Parameter Comparison</TabsTrigger>
                  </TabsList>

                  <TabsContent value="trends" className="mt-6">
                    <div className="h-80">
                      <ResponsiveContainer width="100%" height="100%">
                        <LineChart data={pollutionData}>
                          <CartesianGrid strokeDasharray="3 3" className="stroke-border" />
                          <XAxis dataKey="date" className="text-xs" />
                          <YAxis className="text-xs" />
                          <Tooltip
                            contentStyle={{
                              backgroundColor: "hsl(var(--card))",
                              border: "1px solid hsl(var(--border))",
                              borderRadius: "8px",
                            }}
                          />
                          <Line
                            type="monotone"
                            dataKey="ph"
                            stroke="hsl(var(--chart-1))"
                            strokeWidth={2}
                            name="pH Level"
                          />
                          <Line
                            type="monotone"
                            dataKey="oxygen"
                            stroke="hsl(var(--chart-2))"
                            strokeWidth={2}
                            name="Oxygen (mg/L)"
                          />
                          <Line
                            type="monotone"
                            dataKey="turbidity"
                            stroke="hsl(var(--chart-3))"
                            strokeWidth={2}
                            name="Turbidity (NTU)"
                          />
                        </LineChart>
                      </ResponsiveContainer>
                    </div>
                  </TabsContent>

                  <TabsContent value="comparison" className="mt-6">
                    <div className="h-80">
                      <ResponsiveContainer width="100%" height="100%">
                        <BarChart data={pollutionData.slice(-3)}>
                          <CartesianGrid strokeDasharray="3 3" className="stroke-border" />
                          <XAxis dataKey="date" className="text-xs" />
                          <YAxis className="text-xs" />
                          <Tooltip
                            contentStyle={{
                              backgroundColor: "hsl(var(--card))",
                              border: "1px solid hsl(var(--border))",
                              borderRadius: "8px",
                            }}
                          />
                          <Bar dataKey="ph" fill="hsl(var(--chart-1))" name="pH Level" />
                          <Bar dataKey="oxygen" fill="hsl(var(--chart-2))" name="Oxygen (mg/L)" />
                          <Bar dataKey="temperature" fill="hsl(var(--chart-4))" name="Temperature (°C)" />
                        </BarChart>
                      </ResponsiveContainer>
                    </div>
                  </TabsContent>
                </Tabs>
              </CardContent>
            </Card>

            {/* Current Readings */}
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              <Card>
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium text-muted-foreground">pH Level</p>
                      <p className="text-2xl font-bold text-foreground">{selectedLocation.ph}</p>
                    </div>
                    <div className="h-12 w-12 rounded-full bg-primary/10 flex items-center justify-center">
                      <Droplets className="h-6 w-6 text-primary" />
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium text-muted-foreground">Oxygen</p>
                      <p className="text-2xl font-bold text-foreground">{selectedLocation.oxygen}</p>
                      <p className="text-xs text-muted-foreground">mg/L</p>
                    </div>
                    <div className="h-12 w-12 rounded-full bg-chart-2/10 flex items-center justify-center">
                      <TrendingUp className="h-6 w-6 text-chart-2" />
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium text-muted-foreground">Temperature</p>
                      <p className="text-2xl font-bold text-foreground">24.8°C</p>
                    </div>
                    <div className="h-12 w-12 rounded-full bg-chart-4/10 flex items-center justify-center">
                      <Calendar className="h-6 w-6 text-chart-4" />
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium text-muted-foreground">Status</p>
                      <Badge className={getStatusColor(selectedLocation.status)}>
                        {selectedLocation.status.toUpperCase()}
                      </Badge>
                    </div>
                    <div className="h-12 w-12 rounded-full bg-accent/10 flex items-center justify-center">
                      <AlertTriangle className="h-6 w-6 text-accent" />
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
